import{a as e,_ as n}from"../chunks/3.CkL0OewH.js";export{e as component,n as universal};
