import{s as t}from"../chunks/entry.BUrdsIMN.js";export{t as start};
