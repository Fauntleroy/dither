import{a as e,_ as n}from"../chunks/3.DQbG7DF-.js";export{e as component,n as universal};
