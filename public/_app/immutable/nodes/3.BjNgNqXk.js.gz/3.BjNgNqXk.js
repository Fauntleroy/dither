import{a as e,_ as n}from"../chunks/3.BEl6cISv.js";export{e as component,n as universal};
